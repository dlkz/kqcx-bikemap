# BLE 硬件验证工具

独立 Android 辅助工具，不依赖 BikeMap 主应用。

首个公开发布版：`0.1.10`

## 功能

- BLE、蓝牙、定位和权限检查
- BLE 广播扫描与目标选择
- 原始 BLE 广播载荷和目标 RSSI 记录
- 车辆信息联网核验
- 联网核验结果与现场 BLE 广播的本机比对
- 查询前获取新定位，拒绝超过 2 分钟的旧位置
- 只读设备信息服务枚举
- 标准设备信息与厂商只读信息读取
- 0.5、1、2、5、10 米 RSSI 采样
- ZIP 诊断报告随时导出
- 本机自动保留最近 10 次测试会话
- 右上角一键清空当前填写和结果，并开始新的空白测试会话
- 首次启动展示隐私说明与免责声明，倒计时 10 秒后才能确认

## 技术包名

以下标识只用于安装、升级和构建区分，不属于软件显示名称。

```text
Release: com.kqcx.blehardwaretest
Test:    com.kqcx.blehardwaretest.test
```

可与 BikeMap 主应用同时安装，不共享应用数据。

## 构建

```powershell
$env:JAVA_HOME = "<JDK 17+ 路径>"
$env:ANDROID_HOME = "<Android SDK 路径>"

.\gradlew.bat :app:lintDebug
.\gradlew.bat :app:assembleDebug
.\gradlew.bat :app:assembleRelease
```

APK 输出：

```text
app\build\outputs\apk\debug\app-debug.apk
app\build\outputs\apk\release\app-release.apk
```

## 隐私边界

- 不保存完整车辆编号。
- 不把定位坐标或完整车辆编号写入导出的报告。
- 不保存账号凭据、完整 BLE 地址或第三方服务的原始响应正文。
- BLE 广播载荷会按需记录，可能包含设备序列号；导出前必须确认，且只应发送给可信分析者。
- 联网核验若发现可匹配的蓝牙名称，该名称可能作为本机配对线索保存在诊断会话中；请勿公开分享导出的诊断包。
- 人工备注会原样进入报告和 ZIP，请勿填写坐标、账号或其他身份信息。
- 原始设备信息只保存长度、哈希、掩码和比较结果。
- 不向厂商设备写入或发送控制命令。

## 第三方服务

用户主动执行车辆信息核验时，应用会向配置的第三方车辆服务发送车辆编号、当前位置和完成核验所必需的常规网络请求信息。应用不发送账号凭据，也不保留原始响应正文。该请求仅由用户主动触发。

## 当前状态

本版是 BLE 硬件验证工具的首个公开发布版，主 BikeMap 工程不参与构建。

`dist/0.1.10/` 提供使用独立发布证书签名的 Release APK。签名库和恢复配置保存在项目外的
`BLE-Hardware-Verification-Signing` 目录，项目根目录通过忽略提交的
`keystore.properties` 引用。

缺少签名库或 `keystore.properties` 时，`assembleRelease` 会直接失败，不会生成
未签名正式包。Release 启用 R8 和资源裁剪，对应 mapping 文件随版本归档；
`dist/archive/` 保留历史发布 APK。
